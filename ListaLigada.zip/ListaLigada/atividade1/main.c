#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "listaligada.h"

int main() {

    Lista *li;
    int x, mat = 110, posicao = 1;
    struct aluno al, al2, al3, dados_aluno;

    al.matricula = 100;
    al.n1 = 5.3;
    al.n2 = 4.8;
    al.n3 = 7.8;

    al2.matricula = 120;
    al2.n1 = 7.7;
    al2.n2 = 8.2;
    al2.n3 = 2.4;

    al3.matricula = 110;
    al3.n1 = 4.5;
    al3.n2 = 7.1;
    al3.n3 = 3.2;

    li = criaLista();

    x = tamLista(li);
    printf("O tamanho da lista e %d\n", x);

    if(listaCheia(li)){
        printf("Lista esta cheia!\n");
    }else{
        printf("Lista esta vazia!\n");
    }

    if(listaVazia(li)){
        printf("Lista esta vazia!\n");
    }else{
        printf("Lista nao esta vazia!\n");
    }

    x = insere_inicio_lista(li, al);
    if(x){
        printf("Inserido no inicio com sucesso!\n");
    }else{
        printf("Nao foi possivel inserir no inicio!");
    }

    x = insere_final_lista(li, al2);
    if(x){
        printf("Inserido no final com sucesso!\n");
    }else{
        printf("Nao foi possivel inserir no final!");
    }

    x = insere_inicio_ordenada(li, al3);
    if(x){
        printf("Inserido ordenadamente com sucesso!\n");
    }else{
        printf("Nao foi possivel inserir ordenandamente\n!");
    }

    x = remove_inicio_lista(li);
    if(x){
        printf("Removido do inicio com sucesso!\n");
    }else{
        printf("Nao foi possivel remover do inicio!");
    }

    x = remove_final_lista(li);
    if(x){
        printf("Removido do final com sucesso!\n");
    }else{
        printf("Nao foi possivel remover do final!");
    }

    x = insere_inicio_lista(li, al3);
    if(x){
        printf("Inserido no inicio com sucesso!\n");
    }else{
        printf("Nao foi possivel inserir no inicio!");
    }

    x = remove_lista(li, mat);
    if(x){
        printf("Removido elemento com sucesso!\n");
    }else{
        printf("Nao foi possivel remover o elemento!\n");
    }

    x = insere_inicio_lista(li, al3);
    if(x){
        printf("Inserido no inicio com sucesso!\n");
    }else{
        printf("Nao foi possivel inserir no inicio!");
    }

    x = consulta_lista_pos(li, posicao, &al);

    printf("\nConteudo na posicao %d\n",posicao);
    printf("Matricula: %d\n",al.matricula);
    printf("Nota 1: %.2f\n",al.n1);
    printf("Nota 2: %.2f\n",al.n2);
    printf("Nota 3: %.2f\n",al.n3);

    x = consulta_lista_mat(li, mat, &al);

    printf("\nConteudo na posicao %d\n",posicao);
    printf("Matricula: %d\n",al.matricula);
    printf("Nota 1: %.2f\n",al.n1);
    printf("Nota 2: %.2f\n",al.n2);
    printf("Nota 3: %.2f\n",al.n3);

    apagaLista(li);
}
