#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "listaSequencial.h"

int main()
{
    int x, mat = 110, posicao = 1;
    struct aluno al, al2, al3, dados_aluno;
    Lista *li;

    al.matricula = 100;
    al.n1 = 5.3;
    al.n2 = 4.8;
    al.n3 = 7.8;

    al2.matricula = 120;
    al2.n1 = 7.7;
    al2.n2 = 8.2;
    al2.n3 = 2.4;

    al3.matricula = 110;
    al3.n1 = 4.5;
    al3.n2 = 7.1;
    al3.n3 = 3.2;

    li = cria_lista();

    x = tamanho_lista(li);
    printf("O tamanho da lista e %d\n", x);

    x = lista_cheia(li);
    if(x){
        printf("Lista cheia!\n");
    }else{
        printf("Lista nao esta cheia!\n");
        }

    x = lista_vazia(li);
    if(x){
        printf("Lista vazia!\n");
    }else{
        printf("Lista nao esta vazia!\n");
        }

    x = insere_lista_final(li,al2);
    if(x){
        printf("Aluno inserido no final!\n");
    }else{
        printf("Erro aluno nao inserido!\n");
    }

    x = insere_lista_inicio(li,al);
    if(x){
        printf("Aluno inserido no inicio!\n");
    }else{
        printf("Erro aluno nao inserido!\n");
    }

    x = insere_lista_ordenada(li,al3);
    if(x){
        printf("Aluno inserido ordenado!\n");
    }else{
        printf("Erro aluno nao inserido!\n");
    }

    x = remove_lista_final(li,al2);
    if(x){
        printf("Aluno removido no final!\n");
    }else{
        printf("Erro aluno nao removido!\n");
    }

    x = remove_lista_inicio(li,al2);
    if(x){
        printf("Aluno removido no inicio!\n");
    }else{
        printf("Erro aluno nao removido!\n");
    }

    x = remove_lista(li,mat);
    if(x){
        printf("Aluno removido na posicao especifica!\n");
    }else{
        printf("Erro aluno nao removido!\n");
    }

    x = insere_lista_inicio(li,al3);
    if(x){
        printf("Aluno inserido no inicio!\n");
    }else{
        printf("Erro aluno nao inserido!\n");
    }

    x = consulta_lista_pos(li, posicao, &dados_aluno);
    if(x){
        printf("Consulta por posicao realizada com sucesso!!\n");
        printf("Matricula: %d\n",dados_aluno.matricula);
        printf("Nota 1: %.2f\n",dados_aluno.n1);
        printf("Nota 2: %.2f\n",dados_aluno.n2);
        printf("Nota 3: %.2f\n",dados_aluno.n3);
    }else{
        printf("Nao foi possivel consultar na posicao especifica\n");
    }

    x = consulta_lista_mat(li, mat, &dados_aluno);
    if(x){
        printf("Consulta por posicao realizada com sucesso!!\n");
        printf("Matricula: %d\n",dados_aluno.matricula);
        printf("Nota 1: %.2f\n",dados_aluno.n1);
        printf("Nota 2: %.2f\n",dados_aluno.n2);
        printf("Nota 3: %.2f\n",dados_aluno.n3);
    }else{
        printf("Nao foi possivel consultar matricula especifica");
    }

    libera_lista(li);
}
